package com.demo;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String checkinStr = request.getParameter("checkin");
        String checkoutStr = request.getParameter("checkout");
        String adult = request.getParameter("select1");
        String child = request.getParameter("select2");
        String room = request.getParameter("select3");
        String specialRequest = request.getParameter("message");

        // Parse and format dates
        SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy h:mm a");
        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String checkin = null;
        String checkout = null;
        try {
            Date checkinDate = inputFormat.parse(checkinStr);
            Date checkoutDate = inputFormat.parse(checkoutStr);
            checkin = outputFormat.format(checkinDate);
            checkout = outputFormat.format(checkoutDate);
        } catch (ParseException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
            return;
        }

        // Database connection and SQL query
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Bookings (name, email, checkin, checkout, adult, child, room, special_request) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, checkin);
            stmt.setString(4, checkout);
            stmt.setString(5, adult);
            stmt.setString(6, child);
            stmt.setString(7, room);
            stmt.setString(8, specialRequest);

            // Execute the query
            int rowsAffected = stmt.executeUpdate();

            // Provide feedback to user
            if (rowsAffected > 0) {
                response.sendRedirect("success.jsp"); // Redirect to a success page
            } else {
                response.sendRedirect("error.jsp"); // Redirect to an error page
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database errors
            response.sendRedirect("error.jsp"); // Redirect to an error page
        }
    }
}
