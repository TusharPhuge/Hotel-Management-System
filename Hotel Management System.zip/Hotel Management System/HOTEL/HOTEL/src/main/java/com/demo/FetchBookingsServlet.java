package com.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/fetchBookings")
public class FetchBookingsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Booking> bookings = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Bookings";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat displayFormat = new SimpleDateFormat("MM/dd/yyyy h:mm a");

            while (rs.next()) {
                Booking booking = new Booking();
                booking.setName(rs.getString("name"));
                booking.setEmail(rs.getString("email"));

                // Convert the check-in date format
                String checkin = rs.getString("checkin");
                String formattedCheckin = convertDateFormat(checkin, dbFormat, displayFormat);
                booking.setCheckin(formattedCheckin);

                // Convert the check-out date format
                String checkout = rs.getString("checkout");
                String formattedCheckout = convertDateFormat(checkout, dbFormat, displayFormat);
                booking.setCheckout(formattedCheckout);

                booking.setAdult(rs.getString("adult"));
                booking.setChild(rs.getString("child"));
                booking.setRoom(rs.getString("room"));
                booking.setSpecialRequest(rs.getString("special_request"));
                bookings.add(booking);
            }

            request.setAttribute("bookings", bookings);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
            return;
        }

        request.getRequestDispatcher("viewBookings.jsp").forward(request, response);
    }

    private String convertDateFormat(String dateStr, SimpleDateFormat inputFormat, SimpleDateFormat outputFormat) {
        try {
            return outputFormat.format(inputFormat.parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
