package com.demo;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CheckInOut")
public class CheckInOut extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String checkinStr = request.getParameter("checkin");
        String checkoutStr = request.getParameter("checkout");
        String adultStr = request.getParameter("adult");
        String childStr = request.getParameter("child");

        // Check for null parameters or empty strings
        if (checkinStr == null || checkoutStr == null || adultStr == null || childStr == null ||
            checkinStr.isEmpty() || checkoutStr.isEmpty() || adultStr.isEmpty() || childStr.isEmpty()) {
            response.sendRedirect("error.jsp?message=Missing%20required%20fields");
            return;
        }

        try {
            // Parse date strings to Date objects
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy h:mm a");
            Date checkinDate = dateFormat.parse(checkinStr);
            Date checkoutDate = dateFormat.parse(checkoutStr);

            // Format Date objects to MySQL DATETIME format
            SimpleDateFormat mysqlDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String formattedCheckin = mysqlDateFormat.format(checkinDate);
            String formattedCheckout = mysqlDateFormat.format(checkoutDate);

            // Convert other parameters to integers
            int adult = Integer.parseInt(adultStr);
            int child = Integer.parseInt(childStr);

            // Database connection and insertion
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO CheckInOut (checkin, checkout, adult, child) VALUES (?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, formattedCheckin);
                ps.setString(2, formattedCheckout);
                ps.setInt(3, adult);
                ps.setInt(4, child);
                ps.executeUpdate();
                response.sendRedirect("success.jsp");
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp?message=Database%20error");
            }
        } catch (ParseException | NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?message=Date%20or%20number%20format%20error");
        }
    }
}
